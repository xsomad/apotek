<h2 style="text-align: center;">
	My Simple Page File
</h2>